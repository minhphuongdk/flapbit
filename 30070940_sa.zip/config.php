<?php
return array(
    /**
     * Provide your MYSQL database credentials
     */
    'db_host' => 'localhost',
    'db_username' => 'umenboo',
    'db_name' => 'menboo',
    'db_password' => 'Billgator13797',

    /**
     * Option to know if debug is enabled or not
     */
    'debug' => true,

    /**
     * Option to enable https
     */
    'https' => true,

    /**
     * cookie path
     */
    'cookie_path' => '/',

    'api-key' => 'normalKey',

    'rtl-langs' => array(
        'ar',
        'fa',
    ),

    'installed' => '1'

);